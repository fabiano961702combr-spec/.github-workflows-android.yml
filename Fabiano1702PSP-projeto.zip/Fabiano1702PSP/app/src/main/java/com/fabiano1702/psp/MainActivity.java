package com.fabiano1702.psp;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_GAME = 1702;
    private int cyan = Color.rgb(0, 229, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,13,24));
        getWindow().setNavigationBarColor(Color.rgb(9,13,24));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 48, 28, 28);
        root.setBackgroundColor(Color.rgb(9,13,24));

        TextView logo = new TextView(this);
        logo.setText("FABIANO1702\nPSP GAMER");
        logo.setTextColor(cyan); logo.setTextSize(30); logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER); logo.setLetterSpacing(0.08f);
        root.addView(logo, new LinearLayout.LayoutParams(-1, 150));

        TextView intro = new TextView(this);
        intro.setText("SEU UNIVERSO PLAYSTATION PORTABLE\n\nEscolha um jogo ISO ou CSO para abrir no emulador PPSSPP.");
        intro.setTextColor(Color.WHITE); intro.setTextSize(16); intro.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.setMargins(0, 24, 0, 32); root.addView(intro, ip);

        Button choose = new Button(this);
        choose.setText("ESCOLHER JOGO  •  ISO / CSO");
        choose.setTextColor(Color.BLACK); choose.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan));
        choose.setOnClickListener(v -> pickGame());
        root.addView(choose, new LinearLayout.LayoutParams(-1, 60));

        TextView note = new TextView(this);
        note.setText("\nRequer o PPSSPP instalado.\nAdicione seus próprios jogos obtidos legalmente.\nEste aplicativo é um lançador; não inclui jogos nem o núcleo do emulador.");
        note.setTextColor(Color.LTGRAY); note.setTextSize(13); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.setMargins(0, 30, 0, 0); root.addView(note, np);
        setContentView(root);
    }

    private void pickGame() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-iso9660-image"});
        startActivityForResult(intent, PICK_GAME);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_GAME && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent play = new Intent(Intent.ACTION_VIEW);
            play.setDataAndType(uri, "application/octet-stream");
            play.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { startActivity(Intent.createChooser(play, "Abrir jogo com PPSSPP")); }
            catch (Exception e) { Toast.makeText(this, "Instale o PPSSPP para executar jogos de PSP.", Toast.LENGTH_LONG).show(); }
        }
    }
}
