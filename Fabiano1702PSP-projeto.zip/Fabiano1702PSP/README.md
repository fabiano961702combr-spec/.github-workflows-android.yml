# Fabiano1702 PSP

Projeto Android (Java) de um lançador simples e personalizado para jogos PSP.

## O que faz
- Interface escura com identidade Fabiano1702.
- Abre arquivos selecionados pelo usuário e tenta encaminhá-los ao PPSSPP.
- Aceita seleção de arquivos ISO/CSO por meio do seletor de documentos Android.

## Limitação importante
Este projeto **não é um emulador PSP completo** e não contém jogos. Ele depende do aplicativo PPSSPP instalado no aparelho. Jogos comerciais devem ser obtidos por meios legais; não distribua cópias não autorizadas.

## Gerar o APK
1. Instale o Android Studio.
2. Abra esta pasta no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale Android SDK Platform 35 e Build Tools compatíveis.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.
